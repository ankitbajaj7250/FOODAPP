package com.example.foodapp.util

interface Drawer {
    fun setDrawerEnabled(enabled: Boolean)
}