package com.example.foodapp.model

data class itemlist(val id: String?, val name: String?, val cost: Int?)