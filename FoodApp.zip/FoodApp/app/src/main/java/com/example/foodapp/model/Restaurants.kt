package com.example.foodapp.model

class Restaurants (
    val id: Int,
    val name: String,
    val rating: String,
    val rate2: Int,
    val img: String
)